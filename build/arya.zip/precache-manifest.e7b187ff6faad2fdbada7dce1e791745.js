self.__precacheManifest = [
  {
    "revision": "52250919ce7840b1e38b",
    "url": "/static/css/main.5e6c091f.chunk.css"
  },
  {
    "revision": "52250919ce7840b1e38b",
    "url": "/static/js/main.52250919.chunk.js"
  },
  {
    "revision": "1b922744246c39b6bc43",
    "url": "/static/js/runtime~main.1b922744.js"
  },
  {
    "revision": "219a9096facc25f6027e",
    "url": "/static/css/2.33c99f09.chunk.css"
  },
  {
    "revision": "219a9096facc25f6027e",
    "url": "/static/js/2.219a9096.chunk.js"
  },
  {
    "revision": "c5807fe44f6622444af152c1938109aa",
    "url": "/static/media/logo.c5807fe4.png"
  },
  {
    "revision": "5874c70e25a12419bc931f834b7352c4",
    "url": "/static/media/chirstmas.5874c70e.png"
  },
  {
    "revision": "b7ce44749558bfe5781b612810e70569",
    "url": "/static/media/balloon.b7ce4474.png"
  },
  {
    "revision": "b0da7f02c353b15bcf88486c4c3f0172",
    "url": "/static/media/anniversary (2).b0da7f02.png"
  },
  {
    "revision": "4b1f5f7d96f6467dd0dabd54c03c480f",
    "url": "/static/media/flowers.4b1f5f7d.png"
  },
  {
    "revision": "772af2db47af74dafb9e47e5b4bd6191",
    "url": "/static/media/cake.772af2db.png"
  },
  {
    "revision": "356690e7efd374647c02de6916aa21b5",
    "url": "/static/media/gift.356690e7.png"
  },
  {
    "revision": "735b0fa6d0cd4faba112166b129435bd",
    "url": "/static/media/chocolate.735b0fa6.png"
  },
  {
    "revision": "c8c6988e7dda4fe48bed7dd1b997205d",
    "url": "/static/media/hamper.c8c6988e.png"
  },
  {
    "revision": "2f9946801605c35d5f814ac0fb72d2d6",
    "url": "/static/media/gift-bag.2f994680.png"
  },
  {
    "revision": "4e59f7c5f6275ec64349f95e8e2bdf29",
    "url": "/static/media/18.4e59f7c5.jpg"
  },
  {
    "revision": "a0d7597d1b4176a32e11249d8b3da588",
    "url": "/index.html"
  }
];